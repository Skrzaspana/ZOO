@extends('layouts.app')
@section('content')

    @include('animal.index')
@endsection